import java.util.Scanner;

class AtmInvalidPinOrAcc extends Exception {
    @Override
    public String getMessage() {
        return "Invalid Card details! Try Again.";
    }
}

class InvalidOperation extends Exception {
    @Override
    public String getMessage() {
        return "Invalid operation performed! Try Again.";
    }
}

class AtmCardBlock extends Exception {
    @Override
    public String getMessage() {
        return "Your Card Blocked!. Please try contack Bank";
    }
}

class ATM {
    private int inAccNum;
    private int inPsw;
    Scanner sc = new Scanner(System.in);

    public void acceptIN() {
       
        System.out.println("Enter the Account Number");
        inAccNum = sc.nextInt();
      
        System.out.println("Enter your pin");
        inPsw = sc.nextInt();
    }

    public void validateIn() throws AtmInvalidPinOrAcc, InvalidOperation {
        boolean valid = true;
        Bank bank = new Bank();
        if (inAccNum == bank.getAccNum() && inPsw == bank.getPsw()) {
            while (valid) {
          
                System.out.println(
                        "\n1.check Balance\n2.Withdraw\n3.Deposite\n4.Logout");
                int choice = sc.nextInt();
                System.out.println();
                switch (choice) {
                    case 1:
                        System.out.println("Available balance in your account " + bank.getAccNum()
                                + " is " + bank.getBalance());
                        break;
                    case 2:
                   
                        System.out.println("\nEnter the amount to withdraw:");
                        double amount = sc.nextDouble();
                        if (amount >= bank.getBalance()) {
                            System.out.println("insufficient balance!");
                            break;
                        } else {
                            bank.setBalance(bank.getBalance() - amount);
                            System.out.println("Collect your money: " + amount);
                            System.out.println("Available balance in your account " + bank.getAccNum()
                                    + " is " + bank.getBalance());
                            break;
                        }
                    case 3:
                        System.out.println();
                        System.out.println("Enter the amount to be deposited:");
                        double Amount = sc.nextDouble();
                        bank.setBalance(bank.getBalance() + Amount);
                        System.out.println("Deposited " + Amount + " to your account " + bank.getAccNum());
                        System.out.println("Available balance: " + bank.getBalance());
                        break;
                    case 4:
                        valid = false;
                        System.out.println("Thank you And come Again");
                        break;
                    default:
                        InvalidOperation inv = new InvalidOperation();
                        System.out.println(inv.getMessage());
                }
            }
        } else {
            AtmInvalidPinOrAcc ex = new AtmInvalidPinOrAcc();
            System.out.println();
            System.out.println(ex.getMessage());
            throw ex;
        }
    }
}

class Bank {
    private int AccNum = 789456123;
    private int psw = 753;
    private double balance = 0;

    public int getAccNum() {
        return AccNum;
    }

    public void setAccNum(int accNum) {
        AccNum = accNum;
    }

    public int getPsw() {
        return psw;
    }

    public void setPsw(int psw) {
        this.psw = psw;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void setup() {
        ATM a = new ATM();
        try {
            System.out.println("Please Enter Your Detail To Get Started  \n");
            a.acceptIN();
            a.validateIn();
        } catch (Exception e) {
            try {
                System.out.println("Please Enter Your Detail To Get Started  \n");
                a.acceptIN();
                a.validateIn();
            } catch (Exception f) {
                try {
                    System.out.println("Please Enter Your Detail To Get Started  \n");
                    a.acceptIN();
                    a.validateIn();
                } catch (Exception g) {
                    AtmCardBlock ex = new AtmCardBlock();
                    System.err.println(ex.getMessage());
                }
            }
        }
    }
}


public class AtmInterface {
    static {
        System.out.println("|************************************************|");
        System.out.println("   -|-------------------ATM------------------|-");
        System.out.println("|------------------------------------------------|");
    } 

    public static void main(String[] args) {
        Bank b = new Bank();
        b.setup();
    }
}

